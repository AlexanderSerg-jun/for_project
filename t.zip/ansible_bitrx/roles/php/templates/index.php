<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome Nginx + PHP-FPM</title>
</head>
<body>
    <h1>Welcome Nginx + PHP-FPM</h1>
    <?php
        echo phpinfo();
    ?>
</body>
</html>